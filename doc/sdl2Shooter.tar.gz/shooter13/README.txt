Sound Effects and Music:

10 Guage Shotgun-SoundBible.com-74120584.ogg
	- Copyright Soundbible.com
	- www.soundbible.com

196914__dpoggioli__laser-gun.ogg
	- Laser Gun, by Dpoggioli
	- https://freesound.org/people/Dpoggioli/sounds/196914/

245372__quaker540__hq-explosion.ogg
	- HQ Explosion, by Quaker540
	- https://freesound.org/people/Quaker540/sounds/245372/

334227__jradcoolness__laser.ogg
	- laser.wav, by jradcoolness
	- https://freesound.org/people/jradcoolness/sounds/334227/

Mercury.ogg
	- Mercury, by SketchyLogic
		- https://opengameart.org/users/sketchylogic
	- https://opengameart.org/content/nes-shooter-music-5-tracks-3-jingles

342749__rhodesmas__notification-01.ogg
	- Notification 01, by rhodesmas
	- https://freesound.org/people/rhodesmas/sounds/342749/
	
