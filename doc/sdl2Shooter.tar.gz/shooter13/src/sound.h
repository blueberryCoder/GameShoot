/*
 * Copyright (C) 2015-2018,2022 Parallel Realities. All rights reserved.
 */

void initSounds(void);
void loadMusic(char *filename);
void playMusic(int loop);
void playSound(int id, int channel);
