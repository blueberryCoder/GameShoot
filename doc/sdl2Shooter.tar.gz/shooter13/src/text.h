/*
 * Copyright (C) 2015-2018,2022 Parallel Realities. All rights reserved.
 */

void initFonts(void);
void drawText(int x, int y, int r, int g, int b, char *format, ...);
