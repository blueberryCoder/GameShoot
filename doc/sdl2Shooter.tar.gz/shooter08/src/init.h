/*
 * Copyright (C) 2015-2018,2022 Parallel Realities. All rights reserved.
 */

void initSDL(void);
void cleanup(void);
